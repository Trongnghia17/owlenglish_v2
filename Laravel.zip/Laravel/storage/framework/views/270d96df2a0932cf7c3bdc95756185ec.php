<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="border-bottom pb-3 mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="mb-1 h2 fw-bold">Quiz Builder</h1>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.skills.index')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-2"></i>Quay lại
                        </a>
                        <button type="submit" form="skillForm" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i>Tạo
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Quiz Builder</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.skills.store')); ?>" method="POST" id="skillForm" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- Name -->
                            <div class="mb-3">
                                <label for="name" class="form-label">Quiz Title <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                                    name="name" value="<?php echo e(old('name')); ?>" placeholder="Enter quiz title" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Description -->
                            <div class="mb-3">
                                <label for="description" class="form-label">Quiz Description</label>
                                <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description"
                                    name="description" rows="3"
                                    placeholder="Enter quiz description "><?php echo e(old('description')); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Image -->
                            <div class="mb-3">
                                <label for="image" class="form-label">Hình ảnh</label>
                                <input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image"
                                    name="image" accept="image/*">
                                <small class="form-text text-muted">Chấp nhận: JPG, PNG, GIF. Tối đa: 2MB</small>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div id="imagePreview" class="mt-2" style="display: none;">
                                    <img src="" alt="Preview" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                                </div>
                            </div>
                            <!-- Time Limit -->
                            <div class="mb-3">
                                <label for="time_limit" class="form-label">Time Limit (phút) <span
                                        class="text-danger">*</span></label>
                                <input type="number" class="form-control <?php $__errorArgs = ['time_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="time_limit" name="time_limit" value="<?php echo e(old('time_limit')); ?>" min="1"
                                    placeholder="Nhập thời gian (phút)" required>
                                <small class="form-text text-muted">Thời gian làm bài tính theo phút</small>
                                <?php $__errorArgs = ['time_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                             <!-- Skill Type -->
                            <div class="mb-3">
                                <label for="skill_type" class="form-label">Quiz Preset <span
                                        class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['skill_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="skill_type"
                                    name="skill_type" required>
                                    <option value="">Quiz Preset</option>
                                    <option value="reading" <?php echo e(old('skill_type') == 'reading' ? 'selected' : ''); ?>>
                                        Reading (Đọc)
                                    </option>
                                    <option value="writing" <?php echo e(old('skill_type') == 'writing' ? 'selected' : ''); ?>>
                                        Writing (Viết)
                                    </option>
                                    <option value="listening" <?php echo e(old('skill_type') == 'listening' ? 'selected' : ''); ?>>
                                        Listening (Nghe)
                                    </option>
                                    <option value="speaking" <?php echo e(old('skill_type') == 'speaking' ? 'selected' : ''); ?>>
                                        Speaking (Nói)
                                    </option>
                                </select>
                                <?php $__errorArgs = ['skill_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                             <!-- Is Active -->
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="is_active" name="is_active"
                                        value="1" <?php echo e(old('is_active', 1) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="is_active">
                                       Visible outside syllabus
                                    </label>
                                </div>
                            </div>
                            <!-- Exam Selection -->
                            <div class="mb-3">
                                <label for="exam_id" class="form-label">Quiz Collection <span class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['exam_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exam_id"
                                    name="exam_id" required>
                                    <option value="">Quiz Collection</option>
                                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($exam->id); ?>" <?php echo e(old('exam_id') == $exam->id ? 'selected' : ''); ?>>
                                            <?php echo e($exam->name); ?> (<?php echo e(strtoupper($exam->type)); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['exam_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Test Selection -->
                            <div class="mb-3">
                                <label for="exam_test_id" class="form-label">Quiz Group <span
                                        class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['exam_test_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exam_test_id"
                                    name="exam_test_id" required disabled>
                                    <option value="">-- Please select Quiz Collection first --</option>
                                </select>
                                <?php $__errorArgs = ['exam_test_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                    

                            <!-- Submit -->
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Tạo 
                                </button>
                                <a href="<?php echo e(route('admin.skills.index')); ?>" class="btn btn-secondary">Hủy</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

           
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const examSelect = document.getElementById('exam_id');
                const testSelect = document.getElementById('exam_test_id');
                
                // Image preview
                const imageInput = document.getElementById('image');
                const imagePreview = document.getElementById('imagePreview');
                
                imageInput.addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            imagePreview.querySelector('img').src = e.target.result;
                            imagePreview.style.display = 'block';
                        };
                        reader.readAsDataURL(file);
                    } else {
                        imagePreview.style.display = 'none';
                    }
                });

                // Load tests when exam changes
                examSelect.addEventListener('change', function () {
                    const examId = this.value;

                    // Reset test select
                    testSelect.innerHTML = '<option value="">-- Đang tải... --</option>';
                    testSelect.disabled = true;

                    if (!examId) {
                        testSelect.innerHTML = '<option value="">-- Vui lòng chọn Quiz Collection trước --</option>';
                        return;
                    }

                    // Get tests for selected exam
                    const exams = <?php echo json_encode($exams, 15, 512) ?>;
                    const selectedExam = exams.find(exam => exam.id == examId);

                    if (selectedExam && selectedExam.tests) {
                        testSelect.innerHTML = '<option value="">  Chọn Quiz Group </option>';
                        selectedExam.tests.forEach(test => {
                            const option = document.createElement('option');
                            option.value = test.id;
                            option.textContent = test.name;
                            testSelect.appendChild(option);
                        });
                        testSelect.disabled = false;
                    } else {
                        testSelect.innerHTML = '<option value="">-- Không có test nào --</option>';
                    }
                });

                // Restore selected values if validation fails
                <?php if(old('exam_id')): ?>
                    examSelect.value = "<?php echo e(old('exam_id')); ?>";
                    examSelect.dispatchEvent(new Event('change'));

                    setTimeout(function () {
                        <?php if(old('exam_test_id')): ?>
                            testSelect.value = "<?php echo e(old('exam_test_id')); ?>";
                        <?php endif; ?>
                                }, 100);
                <?php endif; ?>
                });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/admin/skills/create.blade.php ENDPATH**/ ?>