<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Codescandy">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-M8S4MT3EYG"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());

        gtag('config', 'G-M8S4MT3EYG');
    </script>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon/favicon.ico')); ?>">
    <link href="<?php echo e(asset('assets/libs/bootstrap-icons/font/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/libs/%40mdi/font/css/materialdesignicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/libs/simplebar/dist/simplebar.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <title>Admin Trung Tâm</title>


</head>
<style>
    #alert-message {
        opacity: 0;
        transition: opacity 1s ease-in-out;
        /* 1 giây để hiện ra và ẩn đi */
        visibility: hidden;
    }

    #alert-message.show {
        opacity: 1;
        visibility: visible;
    }
</style>

<body>
<main id="main-wrapper" class="main-wrapper">
    <!-- header -->
    <?php echo $__env->make('admin.common.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- navbar vertical -->

    <!-- Sidebar -->

    <?php echo $__env->make('admin.common.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- page content -->
    <div id="app-content">
        <div class="app-content-area">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade alert_message">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-dark alert-dismissible fade alert_message">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-dark alert-dismissible fade alert_message">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>

            
            
            
            

        </div>
    </div>

</main>

<!-- Libs JS -->
<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/feather-icons/dist/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/dist/simplebar.min.js')); ?>"></script>

<!-- Theme JS -->
<script src="<?php echo e(asset('assets/js/theme.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/slug.js')); ?>"></script>
<!-- popper js -->
<script src="<?php echo e(asset('assets/libs/%40popperjs/core/dist/umd/popper.min.js')); ?>"></script>
<!-- tippy js -->



<script>
    document.addEventListener("DOMContentLoaded", function () {
        const successAlert = document.querySelector('.alert-success');
        const errorAlert = document.querySelector('.alert-dark');
        if (successAlert) {
            successAlert.classList.add('show');
            setTimeout(() => {
                successAlert.classList.add('fade-out');
                setTimeout(() => successAlert.remove(),
                    1000);
            }, 5000);
        }
        if (errorAlert) {
            errorAlert.classList.add('show');
            setTimeout(() => {
                errorAlert.classList.add('fade-out');
                setTimeout(() => errorAlert.remove(),
                    1000);
            }, 5000);
        }

        // Ẩn thông báo khi click nút đóng
        const closeButtons = document.querySelectorAll('.btn-close');
        closeButtons.forEach(button => {
            button.addEventListener('click', function () {
                const alert = this.closest('.alert');
                alert.classList.remove('show');
                setTimeout(() => alert.remove(),
                    500);
            });
        });
    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>