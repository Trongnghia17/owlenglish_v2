<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <form action="<?php echo e(route('admin.exams.update', $exam)); ?>" method="POST" enctype="multipart/form-data" id="examForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Header with Tabs -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="mb-0 fw-bold">Bộ đề thi</h3>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" class="btn btn-outline-secondary">
                            Quay lại
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Lưu
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Card -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-4">Bộ đề thi</h5>

                        <!-- Image Upload -->
                        <?php if($exam->image): ?>
                            <div class="mb-3">
                                <label class="form-label">Ảnh bìa hiện tại</label>
                                <div class="position-relative" style="max-width: 300px;">
                                    <img src="<?php echo e(Storage::url($exam->image)); ?>"
                                         alt="<?php echo e($exam->name); ?>"
                                         class="img-thumbnail w-100"
                                         id="currentImage">
                                    <button type="button"
                                            class="btn btn-danger btn-sm position-absolute top-0 end-0 m-2"
                                            onclick="removeCurrentImage()"
                                            style="z-index: 10;">
                                        <i class="bi bi-x-lg"></i>
                                    </button>
                                    <input type="hidden" name="remove_image" id="removeImageFlag" value="0">
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Image Upload -->
                        <div class="mb-3">
                            <label for="image" class="form-label">
                                <?php echo e($exam->image ? 'Thay đổi ảnh bìa' : 'Ảnh bìa'); ?>

                            </label>
                            <input type="file"
                                   class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="image"
                                   name="image"
                                   accept="image/*"
                                   onchange="ImagePreview.show(this)">
                            <small class="form-text text-muted">
                                Định dạng: JPG, PNG, GIF, WEBP. Tối đa 10MB.
                            </small>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <!-- Image Preview (for new uploads) -->
                            <div id="imagePreview" class="mt-3" style="display: none;">
                                <label class="form-label">Xem trước:</label>
                                <div class="position-relative" style="max-width: 300px;">
                                    <img id="preview" src="" alt="Preview" class="img-thumbnail w-100">
                                    <button type="button"
                                            class="btn btn-danger btn-sm position-absolute top-0 end-0 m-2"
                                            onclick="ImagePreview.remove()"
                                            style="z-index: 10;">
                                        <i class="bi bi-x-lg"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Name -->
                        <div class="mb-4">
                            <label for="name" class="form-label fw-semibold">Tiêu đề</label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="name"
                                   name="name"
                                   value="<?php echo e(old('name', $exam->name)); ?>"
                                   placeholder="Nhập tiêu đề ..."
                                   required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Description -->
                        <div class="mb-4">
                            <label for="description" class="form-label fw-semibold">Mô tả</label>
                            <div id="description-editor"></div>
                            <textarea class="form-control d-none <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="description"
                                      name="description"><?php echo e(old('description', $exam->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Type -->
                        <div class="mb-4">
                            <label for="type" class="form-label fw-semibold">Chương trình học</label>
                            <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="type"
                                    name="type"
                                    required>
                                <option value="">-- Chọn chương trình --</option>
                                <option value="ielts" <?php echo e(old('type', $exam->type) == 'ielts' ? 'selected' : ''); ?>>IELTS</option>
                                <option value="toeic" <?php echo e(old('type', $exam->type) == 'toeic' ? 'selected' : ''); ?>>TOEIC</option>
                                <option value="online" <?php echo e(old('type', $exam->type) == 'online' ? 'selected' : ''); ?>>Online</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Is Active -->
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input"
                                       type="checkbox"
                                       id="is_active"
                                       name="is_active"
                                       value="1"
                                       <?php echo e(old('is_active', $exam->is_active) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="is_active">
                                    Hiển thị trên website
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tests List -->
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-4">Nhóm đề thi</h5>

                        <?php $__empty_1 = true; $__currentLoopData = $exam->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card mb-3 border">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="flex-grow-1">
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <h6 class="mb-0 fw-bold"><?php echo e($test->name); ?></h6>
                                            <button type="button" 
                                                    class="btn btn-link btn-sm p-0 text-decoration-none"
                                                    onclick="openEditTestModal(<?php echo e($test->id); ?>, '<?php echo e($test->name); ?>', '<?php echo e(addslashes($test->description ?? '')); ?>', '<?php echo e($test->image ? Storage::url($test->image) : ''); ?>')">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <button type="button" 
                                                    class="btn btn-link btn-sm p-0 text-decoration-none text-danger"
                                                    onclick="deleteTest(<?php echo e($test->id); ?>, '<?php echo e($test->name); ?>')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                        <?php if($test->description): ?>
                                            <p class="text-muted small mb-0"><?php echo e(Str::limit($test->description, 100)); ?></p>
                                        <?php else: ?>
                                            <p class="text-muted small mb-0">Không tồn tại đề kiểm tra</p>
                                        <?php endif; ?>
                                    </div>
                                    
                                </div>

                                <!-- Skills List -->
                                <?php if($test->skills->count() > 0): ?>
                                <div class="border-top pt-3">
                                    <?php $__currentLoopData = $test->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center justify-content-between p-2 mb-2 bg-light rounded">
                                        <div class="d-flex align-items-center gap-2">
                                            <?php if($skill->skill_type == 'reading'): ?>
                                                <i class="bi bi-book text-primary"></i>
                                            <?php elseif($skill->skill_type == 'writing'): ?>
                                                <i class="bi bi-pencil-square text-success"></i>
                                            <?php elseif($skill->skill_type == 'listening'): ?>
                                                <i class="bi bi-headphones text-info"></i>
                                            <?php else: ?>
                                                <i class="bi bi-mic text-warning"></i>
                                            <?php endif; ?>
                                            <span class="fw-semibold"><?php echo e($skill->name); ?></span>
                                            <span class="text-muted small">- <?php echo e($skill->time_limit); ?> phút</span>
                                        </div>
                                        <a href="<?php echo e(route('admin.skills.edit', $skill)); ?>"
                                           class="btn btn-sm btn-outline-primary">
                                            Chỉnh sửa <i class="bi bi-pencil ms-1"></i>
                                        </a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                        <!-- Add Test Button -->
                        <button type="button"
                                class="btn btn-primary w-100"
                                data-bs-toggle="modal"
                                data-bs-target="#createTestModal">
                            <i class="bi bi-plus-circle me-2"></i>Tạo nhóm đề
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Include Create Test Modal -->
<?php echo $__env->make('admin.exams.tests._create_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- Include Edit Test Modal -->
<?php echo $__env->make('admin.exams.tests._edit_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet">
<style>
    .ql-container, .ql-editor {
        min-height: 200px;
        font-size: 14px;
    }
    .object-fit-cover {
        object-fit: cover;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
<script src="<?php echo e(asset('assets/js/admin-editor.js')); ?>"></script>
<script>
let editTestQuill = null;

function removeCurrentImage() {
    const currentImageDiv = document.getElementById('currentImage').parentElement;
    const removeFlag = document.getElementById('removeImageFlag');

    if (confirm('Bạn có chắc muốn xóa ảnh bìa hiện tại?')) {
        currentImageDiv.style.display = 'none';
        removeFlag.value = '1';
    }
}

function removeEditCurrentImage() {
    const wrapper = document.getElementById('edit-current-image-wrapper');
    const removeFlag = document.getElementById('edit-remove-image-flag');
    
    if (confirm('Bạn có chắc muốn xóa ảnh bìa hiện tại?')) {
        wrapper.style.display = 'none';
        removeFlag.value = '1';
        document.getElementById('edit-image-label').textContent = 'Ảnh bìa';
    }
}

function openEditTestModal(testId, testName, testDescription, testImage) {
    // Set form action
    const form = document.getElementById('editTestForm');
    form.action = `/admin/exams/<?php echo e($exam->id); ?>/tests/${testId}`;
    
    // Set name
    document.getElementById('edit-test-name').value = testName;
    
    // Set description in Quill editor
    if (editTestQuill) {
        editTestQuill.root.innerHTML = testDescription || '';
    }
    
    // Handle current image
    const imageWrapper = document.getElementById('edit-current-image-wrapper');
    const currentImage = document.getElementById('edit-current-image');
    const removeFlag = document.getElementById('edit-remove-image-flag');
    const imageLabel = document.getElementById('edit-image-label');
    
    removeFlag.value = '0';
    
    if (testImage) {
        currentImage.src = testImage;
        imageWrapper.style.display = 'block';
        imageLabel.textContent = 'Thay đổi ảnh bìa';
    } else {
        imageWrapper.style.display = 'none';
        imageLabel.textContent = 'Ảnh bìa';
    }
    
    // Clear new image preview
    ImagePreview.remove('edit-test-image', 'editTestImagePreview');
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('editTestModal'));
    modal.show();
}

function deleteTest(testId, testName) {
    if (confirm(`Bạn có chắc muốn xóa nhóm đề "${testName}"?\nHành động này không thể hoàn tác!`)) {
        // Create a form to submit DELETE request
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/admin/exams/<?php echo e($exam->id); ?>/tests/${testId}`;
        
        // Add CSRF token
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrfInput);
        
        // Add DELETE method
        const methodInput = document.createElement('input');
        methodInput.type = 'hidden';
        methodInput.name = '_method';
        methodInput.value = 'DELETE';
        form.appendChild(methodInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}

// Initialize modal test description editor
document.addEventListener('DOMContentLoaded', function() {
    QuillEditor.init('#modal-test-description', 'Nhập mô tả về test này...');
    
    // Initialize edit modal Quill editor with image upload handler
    editTestQuill = new Quill('#edit-test-description-editor', {
        theme: 'snow',
        placeholder: 'Nhập mô tả về test này...',
        modules: {
            toolbar: {
                container: [
                    [{ 'header': [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                    [{ 'color': [] }, { 'background': [] }],
                    ['link', 'image'],
                    ['clean']
                ],
                handlers: {
                    image: imageHandler
                }
            }
        }
    });
    
    // Image upload handler for edit modal
    function imageHandler() {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
        input.click();

        input.onchange = async () => {
            const file = input.files[0];
            if (!file) return;

            // Show loading
            const range = editTestQuill.getSelection(true);
            editTestQuill.insertText(range.index, 'Đang tải ảnh...');
            
            // Upload to server
            const formData = new FormData();
            formData.append('image', file);

            try {
                const response = await fetch('/admin/upload-image', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    }
                });

                const data = await response.json();
                
                // Remove loading text
                editTestQuill.deleteText(range.index, 16);
                
                if (data.success) {
                    // Insert image
                    editTestQuill.insertEmbed(range.index, 'image', data.url);
                    editTestQuill.setSelection(range.index + 1);
                } else {
                    alert('Upload failed: ' + (data.message || 'Unknown error'));
                }
            } catch (error) {
                console.error('Upload error:', error);
                editTestQuill.deleteText(range.index, 16);
                alert('Lỗi khi upload ảnh!');
            }
        };
    }
    
    // Sync Quill content with textarea on form submit
    document.getElementById('editTestForm').addEventListener('submit', function() {
        document.getElementById('edit-test-description').value = editTestQuill.root.innerHTML;
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/admin/exams/edit.blade.php ENDPATH**/ ?>