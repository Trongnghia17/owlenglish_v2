<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-lg-12 col-md-12 col-12">
                <div class="border-bottom pb-3 mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="mb-1 h2 fw-bold">Quản lý bộ đề thi</h1>

                    </div>
                    <div>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#createExamModal">
                            <i class="bi bi-plus-circle me-2"></i>Thêm bộ đề thi mới
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter & Search -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('admin.exams.index')); ?>" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Tìm kiếm</label>
                                <input type="text" name="search" class="form-control" placeholder="Tiêu đề..."
                                    value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Loại</label>
                                <select name="type" class="form-select">
                                    <option value="">Tất cả</option>
                                    <option value="ielts" <?php echo e(request('type') == 'ielts' ? 'selected' : ''); ?>>IELTS</option>
                                    <option value="toeic" <?php echo e(request('type') == 'toeic' ? 'selected' : ''); ?>>TOEIC</option>
                                    <option value="online" <?php echo e(request('type') == 'online' ? 'selected' : ''); ?>>Online</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Trạng thái</label>
                                <select name="is_active" class="form-select">
                                    <option value="">Tất cả</option>
                                    <option value="1" <?php echo e(request('is_active') == '1' ? 'selected' : ''); ?>>Hiển thị</option>
                                    <option value="0" <?php echo e(request('is_active') == '0' ? 'selected' : ''); ?>>Ẩn</option>
                                </select>
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Lọc
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- bộ đề this Table -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-lg">
                                <thead class="table-light">
                                    <tr>
                                        <th>Tiêu đề</th>
                                        <th class="text-center">Ảnh bìa</th>
                                        <th class="text-center">Loại</th>
                                        <th class="text-center">Số Test</th>
                                        <th class="text-center">Ngày tạo</th>
                                        <th class="text-center">Ngày cập nhật</th>
                                        <th class="text-center">Hiển thị</th>
                                        <th class="text-center">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <div class="fw-bold"><?php echo e($exam->name); ?></div>

                                            </td>
                                            <td class="text-center">
                                                <?php if($exam->image): ?>
                                                    <img src="<?php echo e(Storage::url($exam->image)); ?>" alt="<?php echo e($exam->name); ?>"
                                                        class="rounded" style="width: 60px; height: 60px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-light rounded d-flex align-items-center justify-content-center"
                                                        style="width: 60px; height: 60px;">
                                                        <i class="bi bi-image text-muted fs-3"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>

                                            <td class="text-center">
                                                <span class="badge
                                                                                    <?php if($exam->type == 'ielts'): ?> bg-primary
                                                                                    <?php elseif($exam->type == 'toeic'): ?> bg-success
                                                                                    <?php else: ?> bg-info
                                                                                    <?php endif; ?>">
                                                    <?php echo e(strtoupper($exam->type)); ?>

                                                </span>
                                            </td>

                                            <td class="text-center">
                                                <span class="badge bg-secondary"><?php echo e($exam->tests->count()); ?> Test</span>
                                            </td>

                                            <td class="text-center">
                                                <?php echo e($exam->created_at->format('d/m/Y')); ?>

                                            </td>

                                            <td class="text-center">
                                                <?php echo e($exam->updated_at->format('d/m/Y')); ?>

                                            </td>

                                            <td class="text-center">
                                                <form action="<?php echo e(route('admin.exams.toggle-active', $exam)); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit"
                                                        class="btn btn-sm <?php echo e($exam->is_active ? 'btn-success' : 'btn-secondary'); ?>">
                                                        <?php echo e($exam->is_active ? 'Hiển thị' : 'Ẩn'); ?>

                                                    </button>
                                                </form>
                                            </td>
                                            <td class="text-center">
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo e(route('admin.exams.edit', $exam)); ?>"
                                                        class="btn btn-sm btn-warning" title="Sửa">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('admin.exams.destroy', $exam)); ?>" method="POST"
                                                        class="d-inline" onsubmit="return confirm('Bạn có chắc muốn xóa?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger" title="Xóa">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="8" class="text-center py-5">
                                                <i class="bi bi-inbox fs-1 text-muted mb-3 d-block"></i>
                                                <p class="text-muted">Không có bộ đề thi nào</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if($exams->hasPages()): ?>
                            <div class="d-flex justify-content-center mt-4">
                                <?php echo e($exams->links()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('admin.exams._create_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php $__env->startPush('styles'); ?>
        <link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet">
        <style>
            .ql-container,
            .ql-editor {
                min-height: 200px;
                font-size: 14px;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
        <script src="<?php echo e(asset('assets/js/admin-editor.js')); ?>"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Initialize Quill editor for modal
                const modalEditor = QuillEditor.init('#modal-description', 'Nhập mô tả...');

                // Re-open modal if there are validation errors
                <?php if($errors->any()): ?>
                    var createExamModal = new bootstrap.Modal(document.getElementById('createExamModal'));
                    createExamModal.show();
                <?php endif; ?>
                                        });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/admin/exams/index.blade.php ENDPATH**/ ?>