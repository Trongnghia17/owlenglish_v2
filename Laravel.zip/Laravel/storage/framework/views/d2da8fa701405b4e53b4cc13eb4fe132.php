<?php $__env->startSection('content'); ?>
    <div class="app-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <!-- Page header -->
                    <div class="mb-5">
                        <h3 class="mb-0">Quản lý học sinh</h3>
                    </div>
                </div>
            </div>
            <div>
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <!-- card -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <div class="row justify-content-between">
                                    <div class="col-md-6 mb-3">
                                        <a class="btn btn-primary me-2" href="<?php echo e(route('admin.students.create')); ?>">
                                            + Thêm người dùng
                                        </a>
                                    </div>



                                    <div class="col-lg-4 col-md-6">
                                        <form action="<?php echo e(route('admin.students.index')); ?>" method="GET"
                                            class="d-flex mb-3">
                                            <?php if(request('role')): ?>
                                                <input type="hidden" name="role" value="<?php echo e(request('role')); ?>">
                                            <?php endif; ?>
                                            <input type="search" name="q" value="<?php echo e(request('q')); ?>"
                                                class="form-control" placeholder="Tìm kiếm theo tên, email">
                                            <div class="col-auto ms-3">
                                                <button type="submit" class="btn btn-primary">Tìm kiếm</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="table-responsive table-card">
                                    <table class="table text-nowrap mb-0 table-centered table-hover">
                                        <thead class="table-light">
                                            <tr>
                                                <th>STT</th>
                                                <th>Tên</th>
                                                <th>Email</th>
                                                <th>Số điện thoại</th>
                                                <th>Ngày tạo</th>
                                                <th>Trạng thái</th>
                                                <th>Đăng nhập bằng</th>
                                                <th>Chức năng</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e(($students->currentPage() - 1) * $students->perPage() + $loop->iteration); ?>

                                                    </td>
                                                    <td class="ps-1">
                                                        <div class="d-flex align-items-center">
                                                            <div class="ms-2">
                                                                <h5 class="mb-0">
                                                                    <a class="text-inherit">
                                                                        <?php if($user->name): ?>
                                                                            <?php echo e($user->name); ?>

                                                                        <?php else: ?>
                                                                            <span class="badge bg-secondary"
                                                                                style="font-size: 11px;">Chưa
                                                                                có</span>
                                                                        <?php endif; ?>
                                                                    </a>
                                                                </h5>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td>
                                                        <?php if($user->phone): ?>
                                                            <?php echo e($user->phone); ?>

                                                        <?php else: ?>
                                                            <span class="badge bg-secondary" style="font-size: 11px;">Chưa
                                                                có</span>
                                                        <?php endif; ?>
                                                    </td>

                                                    <td><?php echo e($user->created_at->format('d/m/Y H:i')); ?></td>
                                                    <td>
                                                        <?php if($user->is_active): ?>
                                                            <span class="badge badge-success-soft text-success">Hoạt
                                                                động</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger-soft text-danger">Không hoạt
                                                                động</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex gap-2">
                                                            <?php $__currentLoopData = $user->login_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <img src="/icons/<?php echo e($method); ?>.svg"
                                                                    title="<?php echo e(strtoupper($method)); ?>"
                                                                    style="width:20px;height:20px;">
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            
                                                            <?php if($user->login_methods == null || count($user->login_methods) === 0): ?>
                                                                <img src="/icons/local.svg" title="Local account"
                                                                    style="width:20px;height:20px;">
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <a class="btn btn-ghost btn-icon btn-sm rounded-circle texttooltip"
                                                            href="<?php echo e(route('admin.students.edit', $user->id)); ?>"
                                                            data-bs-toggle="tooltip" title="Chỉnh sửa">
                                                            <i data-feather="edit" class="icon-xs"></i>
                                                        </a>


                                                        <!-- Delete button -->
                                                        <?php if($user->id !== auth()->id()): ?>
                                                            <a class="btn btn-ghost btn-icon btn-sm rounded-circle texttooltip"
                                                                data-template="trashOne" data-bs-toggle="modal"
                                                                data-bs-target="#deleteUserModal<?php echo e($user->id); ?>">
                                                                <i data-feather="trash-2" class="icon-xs"></i>
                                                            </a>
                                                        <?php endif; ?>

                                                        <!-- Delete Modal -->
                                                        <?php if($user->id !== auth()->id()): ?>
                                                            <div class="modal fade" id="deleteUserModal<?php echo e($user->id); ?>"
                                                                tabindex="-1"
                                                                aria-labelledby="deleteUserModalLabel<?php echo e($user->id); ?>"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <form
                                                                        action="<?php echo e(route('admin.students.destroy', $user)); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <div class="modal-content border-0 shadow">
                                                                            <div class="modal-header bg-danger text-white">
                                                                                <h5 class="modal-title"
                                                                                    id="deleteUserModalLabel<?php echo e($user->id); ?>">
                                                                                    <i class="fe fe-trash-2 me-2"></i>Xác
                                                                                    nhận xoá
                                                                                </h5>
                                                                                <button type="button"
                                                                                    class="btn-close btn-close-white"
                                                                                    data-bs-dismiss="modal"
                                                                                    aria-label="Đóng"></button>
                                                                            </div>
                                                                            <div class="modal-body p-4">
                                                                                <div class="text-center mb-3">
                                                                                    <div class="avatar avatar-lg mb-3">
                                                                                        <span
                                                                                            class="avatar-text rounded-circle bg-danger-soft text-danger">
                                                                                            <i data-feather="alert-triangle"
                                                                                                class="icon-md"></i>
                                                                                        </span>
                                                                                    </div>
                                                                                    <h5 class="mb-3">Bạn có chắc chắn muốn
                                                                                        xoá?</h5>
                                                                                    <p class="mb-0">Người dùng <span
                                                                                            class="fw-bold text-danger"><?php echo e($user->name); ?></span>
                                                                                        sẽ bị xóa khỏi hệ thống.</p>
                                                                                </div>
                                                                            </div>
                                                                            <div
                                                                                class="modal-footer border-top-0 pt-0 pb-3 px-4">
                                                                                <button type="button"
                                                                                    class="btn btn-light-soft"
                                                                                    data-bs-dismiss="modal">
                                                                                    <i data-feather="x"
                                                                                        class="icon-xs me-1"></i>
                                                                                    Huỷ bỏ
                                                                                </button>
                                                                                <button type="submit"
                                                                                    class="btn btn-danger">
                                                                                    <i data-feather="trash-2"
                                                                                        class="icon-xs me-1"></i> Xoá
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="7" class="text-center py-4">
                                                        <div class="d-flex flex-column align-items-center">
                                                            <i data-feather="users" class="icon-lg text-muted mb-2"></i>
                                                            <p class="text-muted">Không có người dùng nào được tìm thấy</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/admin/students/index.blade.php ENDPATH**/ ?>