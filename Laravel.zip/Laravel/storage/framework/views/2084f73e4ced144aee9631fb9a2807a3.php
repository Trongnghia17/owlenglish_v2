<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-lg-12">
            <div class="border-bottom pb-3 mb-3 d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="mb-1 h2 fw-bold">Quản lý dề thi</h1>
                </div>
                <div>
                    <a href="<?php echo e(route('admin.skills.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>Thêm đê thi mới
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.skills.index')); ?>" method="GET" class="row g-3">
                <!-- Search -->
                <div class="col-md-3">
                    <label class="form-label">Tìm kiếm</label>
                    <input type="text"
                           class="form-control"
                           name="search"
                           value="<?php echo e(request('search')); ?>"
                           placeholder="Tên đê thi...">
                </div>

                <!-- Skill Type -->
                <div class="col-md-2">
                    <label class="form-label">Loại đề thi</label>
                    <select class="form-select" name="skill_type">
                        <option value="">Tất cả</option>
                        <option value="reading" <?php echo e(request('skill_type') == 'reading' ? 'selected' : ''); ?>>Reading</option>
                        <option value="writing" <?php echo e(request('skill_type') == 'writing' ? 'selected' : ''); ?>>Writing</option>
                        <option value="listening" <?php echo e(request('skill_type') == 'listening' ? 'selected' : ''); ?>>Listening</option>
                        <option value="speaking" <?php echo e(request('skill_type') == 'speaking' ? 'selected' : ''); ?>>Speaking</option>
                    </select>
                </div>

                <!-- Exam -->
                <div class="col-md-3">
                    <label class="form-label">Bộ đề thi</label>
                    <select class="form-select" name="exam_id">
                        <option value="">Tất cả</option>
                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($exam->id); ?>" <?php echo e(request('exam_id') == $exam->id ? 'selected' : ''); ?>>
                                <?php echo e($exam->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Test -->
                <div class="col-md-3">
                    <label class="form-label">Nhóm đề thi</label>
                    <select class="form-select" name="test_id">
                        <option value="">Tất cả</option>
                        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($test->id); ?>" <?php echo e(request('test_id') == $test->id ? 'selected' : ''); ?>>
                                <?php echo e($test->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Buttons -->
                <div class="col-md-1">
                    <label class="form-label">&nbsp;</label>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i>
                        </button>
                        <a href="<?php echo e(route('admin.skills.index')); ?>" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i>
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Skills List -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Danh sách đè thi (<?php echo e($skills->total()); ?>)</h5>
        </div>
        <div class="card-body p-0">
            <?php if($skills->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Tiêu đè</th>
                                <th>Loại</th>
                                <th>Bộ đê thi</th>
                                <th>Nhóm đê thi</th>
                                <th>Thời gian</th>
                                <th>Trạng thái</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td>
                                        <strong><?php echo e($skill->name); ?></strong>
                                    </td>
                                    <td>
                                        <?php
                                            $badgeClass = [
                                                'reading' => 'bg-primary',
                                                'writing' => 'bg-success',
                                                'listening' => 'bg-info',
                                                'speaking' => 'bg-warning'
                                            ][$skill->skill_type] ?? 'bg-secondary';
                                        ?>
                                        <span class="badge <?php echo e($badgeClass); ?>">
                                            <?php echo e(strtoupper($skill->skill_type)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($skill->examTest && $skill->examTest->exam): ?>
                                            <?php echo e($skill->examTest->exam->name); ?>

                                            <br>
                                            <span class="badge bg-secondary"><?php echo e(strtoupper($skill->examTest->exam->type)); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($skill->examTest): ?>
                                            <?php echo e($skill->examTest->name); ?>

                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <i class="bi bi-clock me-1"></i><?php echo e($skill->time_limit); ?> phút
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.skills.toggle-active', $skill)); ?>"
                                              method="POST"
                                              class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit"
                                                    class="btn btn-sm <?php echo e($skill->is_active ? 'btn-success' : 'btn-secondary'); ?>">
                                                <?php echo e($skill->is_active ? 'Hiển thị' : 'Ẩn'); ?>

                                            </button>
                                        </form>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('admin.skills.edit', $skill)); ?>"
                                               class="btn btn-sm btn-outline-primary"
                                               title="Sửa">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.skills.destroy', $skill)); ?>"
                                                  method="POST"
                                                  class="d-inline"
                                                  onsubmit="return confirm('Bạn có chắc chắn muốn xóa đê thi này?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                        class="btn btn-sm btn-outline-danger"
                                                        title="Xóa">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox display-1 text-muted"></i>
                    <p class="text-muted mt-3">Chưa có đê thi nào</p>
                    <a href="<?php echo e(route('admin.skills.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>Thêm đê thi đầu tiên
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <?php if($skills->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($skills->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/admin/skills/index.blade.php ENDPATH**/ ?>