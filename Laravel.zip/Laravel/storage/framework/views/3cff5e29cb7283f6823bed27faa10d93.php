<?php $__env->startSection('content'); ?>
<div class="container mt-4">
	<a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-primary me-2 mb-3">← Quay lại danh sách</a>
	<div class="card">
		<div class="card-body">
			<h3 class="card-title">Thêm tài khoản học sinh</h3>
			<form action="<?php echo e(route('admin.students.store')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>

				<div class="mb-3">
					<label for="name" class="form-label">Họ và tên <span class="text-danger">*</span></label>
					<input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
				</div>

				<div class="row">
					<div class="col-md-6 mb-3">
						<label for="email" class="form-label">Email</label>
						<input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
					</div>

					<div class="col-md-6 mb-3">
						<label for="phone" class="form-label">Số điện thoại</label>
						<input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" placeholder="0912345678">
					</div>
				</div>

				<div class="row">
					<div class="col-md-6 mb-3">
						<label for="password" class="form-label">Mật khẩu</label>
						<input type="password" id="password" name="password" class="form-control" placeholder="Để trống sẽ dùng mật khẩu mặc định">
						<div class="form-text">Mật khẩu tối thiểu 6 ký tự. Nếu để trống, hệ thống sẽ tạo mật khẩu mặc định.</div>
					</div>
				</div>

				<div class="mb-3">
					<label for="avatar" class="form-label">Avatar (tùy chọn)</label>
					<input type="file" id="avatar" name="avatar" class="form-control">
				</div>

				<div class="d-flex gap-2">
					<button type="submit" class="btn btn-primary">Lưu</button>
					<a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-secondary">Hủy</a>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\owlenglish_v2\Laravel\resources\views/admin/students/create.blade.php ENDPATH**/ ?>